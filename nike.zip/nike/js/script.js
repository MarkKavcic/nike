function barva(color){
  console.log(parseColor(color))
	document.getElementById('krivulja').style.fill=parseColor(color);
}

function barva2(color){
	document.getElementById('deck').style.fill=parseColor(color);
}

function parseColor(color) {
  let rgb = color.rgb;
  return `rgb(${rgb[0]}, ${rgb[1]}, ${rgb[2]})`
}

/*function svgslika(){
  if(article==0)
    console.log("že izbrano");
  else{
    article=0;
    console.log("svg slika: "+article);
    document.getElementById('krivulja').style.visibility="visible";
    document.getElementById('slika').style.visibility="hidden";
	document.getElementById('bezier').style.visibility="hidden";
  }
}

function slika(){
  if(article==1)
   console.log("že izbrano");
  else{
    article=1;
    console.log("slika: "+article);
    document.getElementById('slika').style.visibility="visible";
    document.getElementById('krivulja').style.visibility="hidden";
	document.getElementById('bezier').style.visibility="hidden";
  }
}

function bezier(){
    console.log("test");
	.style.display="none";
  }*/